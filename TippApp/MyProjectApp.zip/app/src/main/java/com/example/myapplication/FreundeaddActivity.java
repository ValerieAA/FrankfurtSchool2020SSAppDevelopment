package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Toast;

import com.example.myapplication.SQL.DataBaseHelperFriends;
import com.example.myapplication.SQL.DatabaseHelper;
import com.example.myapplication.utils.PreferenceUtils;

public class FreundeaddActivity extends AppCompatActivity {
    DatabaseHelper db;
    DataBaseHelperFriends dbf;
    int userID;
    String Username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_freundeadd);

        db = new DatabaseHelper(this);
        dbf = new DataBaseHelperFriends(this);
        Username = PreferenceUtils.getUsername(this);

        userID = db.userID(Username);

        Toast.makeText(this, "userID "+ userID, Toast.LENGTH_SHORT).show();

    }


}
