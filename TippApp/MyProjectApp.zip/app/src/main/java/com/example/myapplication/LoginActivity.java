package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.myapplication.SQL.DatabaseHelper;
import com.example.myapplication.utils.PreferenceUtils;

public class LoginActivity extends AppCompatActivity {
    private Button register, login;
    EditText username, password;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);



        db = new DatabaseHelper(this);
        setupUIViews();

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = username.getText().toString();
                String pass = password.getText().toString();
                if(validate(name, pass)){
                        Intent LoggedIn = new Intent(getApplicationContext(), HauptmaskeActivity.class);
                        startActivity(LoggedIn);
                        finish();
                }
            }
        });

        register = (Button)findViewById(R.id.Register);
        register.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                openRegisterActivity();
            }
        });

        //initViews();
    }

    private void initViews(){

        if(!PreferenceUtils.getUsername(this).equals("")){
            Intent intent = new Intent (LoginActivity.this, HauptmaskeActivity.class);
            startActivity(intent);
        }

    }

    private void setupUIViews() {
        username = (EditText)findViewById(R.id.username);
        password = (EditText)findViewById(R.id.Password);
        login = (Button)findViewById(R.id.login);
    }

    private boolean validate(String name, String pass){
        boolean result = false;

        String Username = username.getText().toString();
        String Passwort = password.getText().toString();
        boolean userpass = db.userpassword(name,pass);


        if(Username.isEmpty() || Passwort.isEmpty()){
            Toast.makeText(this, "Please enter all the details", Toast.LENGTH_SHORT).show();
        }
        else if (userpass == false){
            Toast.makeText(getApplicationContext(),"Wrong email or password", Toast.LENGTH_SHORT).show();
            return result;
        }
        else {
            PreferenceUtils.saveUsername(Username, this);
            PreferenceUtils.savePassword(Passwort, this);
            result = true;
        }

        return result;

    }

    public void openRegisterActivity(){
        Intent intent = new Intent(this, RegisterActivity.class);
        startActivity(intent);
    }
}
