package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import com.example.myapplication.utils.PreferenceUtils;
import com.google.android.material.navigation.NavigationView;

public class HauptmaskeActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener,HauptmaskeFragment.onFragmentBtnSelected {
    DrawerLayout drawerLayout;
    ActionBarDrawerToggle actionBarDrawerToggle;
    Toolbar toolbar;
    NavigationView navigationView;
    FragmentManager fragmentManager;
    FragmentTransaction fragmentTransaction;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hauptmaske);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        drawerLayout = findViewById(R.id.drawer);
        navigationView = findViewById(R.id.navigationView);
        navigationView.setNavigationItemSelectedListener(this);

        actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.open, R.string.close);
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.setDrawerIndicatorEnabled(true);
        actionBarDrawerToggle.syncState();

        // load fragment
        fragmentManager = getSupportFragmentManager();
        fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.add(R.id.container_fragment,new HauptmaskeFragment());
        fragmentTransaction.commit();
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        Intent intent;
        if(menuItem.getItemId() == R.id.groups) {
            startActivity(new Intent(this, HauptmaskeActivity.class));
        }
        if(menuItem.getItemId() == R.id.friends) {
            startActivity(new Intent(this, FreundeHinzufuegenActivity.class));
        }
        if(menuItem.getItemId() == R.id.friendrequests) {
            startActivity(new Intent(this, FreundschaftsanfragenActivity.class));
        }
        if(menuItem.getItemId() == R.id.logout) {
            PreferenceUtils.saveUsername("" ,this);
            PreferenceUtils.savePassword("" ,this);
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            Toast.makeText(this, "Logout successful", Toast.LENGTH_SHORT).show();
        }

        drawerLayout.closeDrawer(GravityCompat.START);

        return true;
    }

    @Override
    public void onButtonSelected() {
        startActivity(new Intent(this, GruppeHinzufuegenActivity.class));
    }
}
