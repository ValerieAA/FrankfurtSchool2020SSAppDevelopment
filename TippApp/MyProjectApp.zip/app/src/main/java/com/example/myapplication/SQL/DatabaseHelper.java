package com.example.myapplication.SQL;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DatabaseHelper extends SQLiteOpenHelper {


    public DatabaseHelper(@Nullable Context context) {
        super(context, "TippApp.db", null, 3);
        SQLiteDatabase db = this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table users ( ID Integer Primary Key Autoincrement, Username Text, email Text, password Text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists users");
    }

    //

    //inserting in database
    public boolean insert(String username,String email, String password){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("Username",username);
        contentValues.put("email",email);
        contentValues.put("password",password);
        long ins = db.insert("users", null, contentValues);

        if(ins== -1) return false;
        else return true;
    }

    //checking if email exists
    public boolean checkmail(String email){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("Select email from users where email=?",new String[]{email});
        if(cursor.getCount()>0) return false;
        else return true;
    }

    //checking if Username exists
    public boolean checkusername(String username){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("Select Username from users where Username=?",new String[]{username});
        if(cursor.getCount()>0) return false;
        else return true;
    }

    //checking email and password for login
    public boolean userpassword(String username, String password){
       SQLiteDatabase db = this.getReadableDatabase();
       Cursor cursor = db.rawQuery("Select Username, password from users where Username=? and password=?", new String []{username,password});

       if(cursor.getCount()>0){
           return true;
       }
       else return false;
    }

    //ID von User holen
    public int userID(String username){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("Select ID from users where Username=?",new String[]{username});
        int i = 99999;
        cursor.moveToFirst();

        while(!cursor.isAfterLast()){
            i = cursor.getInt(cursor.getColumnIndex("ID"));
        }
        return i;
    }

}
