package com.example.myapplication.utils;

public class Constants {
    public static String KEY_USERNAME = "username";
    public static String KEY_PASSWORD = "password";
}
