package com.example.myapplication.SQL;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DataBaseHelperFriends extends SQLiteOpenHelper {

    public DataBaseHelperFriends(@Nullable Context context) {
        super(context, "TippApp.db", null, 3);
        SQLiteDatabase db = this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table friends ( ID Integer Primary Key Autoincrement, userID, Username Text, Friend Text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists friends");
    }

}
