package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.myapplication.SQL.DatabaseHelper;

public class RegisterActivity extends AppCompatActivity {
    DatabaseHelper db;
    private EditText username,email, password, passwordrepeat;
    private Button regButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        db = new DatabaseHelper(this);
        setupUIViews();
        regButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(validate()){
                    String name = username.getText().toString();
                    String mail = email.getText().toString();
                    String passwort = password.getText().toString();
                    Boolean insert = db.insert(name,mail,passwort);

                    if(insert=true){
                        Toast.makeText(getApplicationContext(), "Registered succesfull", Toast.LENGTH_SHORT).show();
                    }

                }
            }
        });
    }

    private void setupUIViews() {
        username = (EditText)findViewById(R.id.UsernameRegister);
        email = (EditText)findViewById(R.id.Email);
        password = (EditText)findViewById(R.id.Password);
        passwordrepeat = (EditText)findViewById(R.id.repeatpassword);
        regButton = (Button)findViewById(R.id.Register);
    }

    private boolean validate(){
        boolean result = false;

        String name = username.getText().toString();
        String mail = email.getText().toString();
        String passwort = password.getText().toString();
        String passwortrepeat = passwordrepeat.getText().toString();
        boolean checkmail = db.checkmail(mail);
        boolean checkusername = db.checkusername(name);

        if(name.isEmpty() || mail.isEmpty() || passwort.isEmpty() || passwortrepeat.isEmpty()){
            Toast.makeText(this, "Please enter all the details", Toast.LENGTH_SHORT).show();
        }
        else if(!passwort.equals(passwortrepeat)){
            Toast.makeText(this, "Passwords are not the same", Toast.LENGTH_SHORT).show();
        }
        else if(checkmail == false){
            Toast.makeText(this, "Email already exists", Toast.LENGTH_SHORT).show();
        }
        else if(checkusername == false){
            Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show();
        }
        else{
            result = true;
        }

        return result;
    }
}
